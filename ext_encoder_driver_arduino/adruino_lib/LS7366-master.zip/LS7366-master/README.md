# LS7366
An Arduino library to interface to the LS7366 quadrature encoder counter.
